-- Kiadás típusa (album / ep / single), a MusicBrainz-ből. A landing "Album" számlálója ebből dolgozik,
-- így nem függ attól, hogy a Spotify-pótlás már hozzáadta-e a valódi dallistát.
alter table albums add column if not exists release_type text;

-- A már meglévő, legalább 4 dalos kiadások biztosan albumok (a többi típusát az import --retype futása tölti ki)
update albums
set release_type = 'album'
where release_type is null
  and id in (select album_id from tracks group by album_id having count(*) >= 4);

-- Album-számláló: album vagy EP típusú kiadások; ha a típus még nincs kitöltve, a dalok száma dönt (mint eddig)
create or replace function album_count(p_min_tracks int default 4)
returns bigint
language sql
stable
as $$
  select count(*)
  from albums a
  where a.release_type in ('album', 'ep')
     or (
       a.release_type is null
       and (select count(*) from tracks t where t.album_id = a.id) >= p_min_tracks
     )
$$;

grant execute on function album_count(int) to anon, authenticated;
