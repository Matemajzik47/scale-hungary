-- Gyanús előadók keresése: azonos nevű, de más személyek összeolvadása.
-- Csak olvas, nem módosít semmit.

-- 1) Olyan előadók, akiknek a neve egy korábban kihagyott (külföldi) előadóéval megegyezik
select ar.id, ar.name, ar.mb_artist_id,
       (select count(*) from albums a where a.artist_id = ar.id) as albumok
from artists ar
join skipped_artists s on lower(s.name) = lower(ar.name)
order by ar.name;

-- 2) Előadók, akiknek a kiadásai között 25 évnél nagyobb a szakadék (ez általában két különböző személy)
select ar.id, ar.name, ar.mb_artist_id, count(*) as albumok,
       min(a.release_date) as legrégebbi, max(a.release_date) as legújabb
from artists ar
join albums a on a.artist_id = ar.id
where a.release_date is not null
group by ar.id, ar.name, ar.mb_artist_id
having max(a.release_date) - min(a.release_date) > 25 * 365
order by albumok desc;
